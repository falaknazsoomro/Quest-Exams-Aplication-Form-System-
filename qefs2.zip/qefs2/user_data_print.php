<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show All Records</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="print.css" media="print">

</head>
<body>
    <div class="container">
        
                        <div id="myForm">
                            <form action="" method="POST">
                                <input type="text" name="id" placeholder="Enter Student Id" />
                                <input type="submit" name="search" value="Search by Id">

                            </form>
                            <br>
                            <br>
                        </div>

                        
                       
                                        <?php 
                                                include ('connection.php');

                                                $query = "SELECT * FROM students";
                                                $query_run = mysqli_query($conn,$query);

                                                if(isset($_POST['search']))
                                                {
                                                    $id = $_POST['id'];

                                                    $query = "SELECT * FROM students where id='$id'";
                                                    $query_run = mysqli_query($conn,$query);

                                                    while($row = mysqli_fetch_array($query_run))
                                                    {
                                                        ?>


                                                    <div id="myTable">

                                                        <table width="1300">
                                                            <tr>
                                                               
                                                            

                                                                <!-- this is modified-->

                                                                 <!-- this is modified-->

                                                                 <td style="border:1px solid black;" width = "400">
                                                                <pre style="text-align:left">&nbsp<img src="img/nbplogo.png" width="30">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bank's Copy</pre>
                                                                <pre> Serial No.________   Date:___________</pre>
                                                                <!-- <p style="font-size:10px;font-weight:bold;text-align:center;">YOUR SERVICE IS OUR PRIDE
                                                                    SAFE AND SHOULD ALL PROUD <br></p> -->
                                                                   <p style="font-size:23px;font-weight:bold;text-align:center;">National Bank of Pakistan</p>

                                                                    <!-- <div class="uni"> -->
                                                                    <p style="font-size:10px;font-weight:bold;text-align:center;">QUAID-E-AWAM UNIVERSITY OF ENGINEERING <br>SCIENCE & TECHNOLOGY NAWABSHAH</p>
                                                                
                                                                    <p style="font-size:13px;font-weight:bold;text-align:center;">Please receive and credit to QUEST <br>
                                                                    Account No: <u>NIDA-11</u> -7  <br>Challan Fee: <br> Sig. & Stamp of Sectional Head
                                                                    (QUEST) </p>
                                           
                                                                    
                                                                    <!-- </div> -->
                                                                    <p style="font-size:15px;">
                                                                    &nbsp;Name: &nbsp;&nbsp;<b><?= $row['studentName']; ?></b><br>
                                                                    &nbsp;Father's Name:&nbsp;&nbsp;<b><?= $row['father']; ?></b><br>
                                                                    &nbsp;Roll No: &nbsp;&nbsp;<b><?= $row['seatNo']; ?></b><br>
                                                                    &nbsp;NIC No: &nbsp;&nbsp;<b><?= $row['nic']; ?></b><br>
                                                                    &nbsp;Cell No: &nbsp;&nbsp;<b><?= $row['cellNo']; ?></b>
                                                                    <br>&nbsp;Sig. Of Student:__________________________</p>


                                                                    <table border="1" align="center" width = "300" height = "180">
                                                                        <tr style="border:1px solid black;">
                                                                            <th>Examination Fees</th>
                                                                            <th>Amount</th>
                                                                        </tr>

                                                                        <tr style="border:1px solid black;">
                                                                            <td style="border:1px solid black;">1. Examination Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">2. Pass Marks Certificate Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">3. Degree Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">4. Transcript Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">5. Others</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">Total</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>
                                                                    </table>
                                                                    <p style= "font-size:15px;"> &nbsp;Rupees...............................................................<br>
                                                                    &nbsp;(In words)............................................................</p>
                                                                <br>
                                                                <pre><b>CASHIER                     OFFICER</b></pre>

                                                                </td>

                                                                <!-- this is modified-->

                                                                 <!-- this is modified-->

                                                                 <td style="border:1px solid black;" width = "400">
                                                                <pre style="text-align:left">&nbsp<img src="img/nbplogo.png" width="30">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Account's Branch Copy</pre>
                                                                <pre> Serial No.________   Date:___________</pre>
                                                                <!-- <p style="font-size:10px;font-weight:bold;text-align:center;">YOUR SERVICE IS OUR PRIDE
                                                                    SAFE AND SHOULD ALL PROUD <br></p> -->
                                                                   <p style="font-size:23px;font-weight:bold;text-align:center;">National Bank of Pakistan</p>

                                                                    <!-- <div class="uni"> -->
                                                                    <p style="font-size:10px;font-weight:bold;text-align:center;">QUAID-E-AWAM UNIVERSITY OF ENGINEERING <br>SCIENCE & TECHNOLOGY NAWABSHAH</p>
                                                                
                                                                    <p style="font-size:13px;font-weight:bold;text-align:center;">Please receive and credit to QUEST <br>
                                                                    Account No: <u>NIDA-11</u> -7  <br>Challan Fee: <br> Sig. & Stamp of Sectional Head
                                                                    (QUEST) </p>
                                           
                                                                    
                                                                    <!-- </div> -->
                                                                    <p style="font-size:15px;">
                                                                    &nbsp;Name: &nbsp;&nbsp;<b><?= $row['studentName']; ?></b><br>
                                                                    &nbsp;Father's Name:&nbsp;&nbsp;<b><?= $row['father']; ?></b><br>
                                                                    &nbsp;Roll No: &nbsp;&nbsp;<b><?= $row['seatNo']; ?></b><br>
                                                                    &nbsp;NIC No: &nbsp;&nbsp;<b><?= $row['nic']; ?></b><br>
                                                                    &nbsp;Cell No: &nbsp;&nbsp;<b><?= $row['cellNo']; ?></b>
                                                                    <br>&nbsp;Sig. Of Student:__________________________</p>


                                                                    <table border="1" align="center" width = "300" height = "180">
                                                                        <tr style="border:1px solid black;">
                                                                            <th>Examination Fees</th>
                                                                            <th>Amount</th>
                                                                        </tr>

                                                                        <tr style="border:1px solid black;">
                                                                            <td style="border:1px solid black;">1. Examination Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">2. Pass Marks Certificate Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">3. Degree Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">4. Transcript Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">5. Others</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">Total</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>
                                                                    </table>
                                                                    <p style= "font-size:15px;">&nbsp;Rupees...............................................................<br>
                                                                    &nbsp;(In words)............................................................</p>
                                                                <br>
                                                                <pre><b>CASHIER                     OFFICER</b></pre>

                                                                </td>

                                                                <!-- this is modified-->

                                                                 <!-- this is modified-->

                                                                 <td style="border:1px solid black;" width = "400">
                                                                <pre style="text-align:left">&nbsp<img src="img/nbplogo.png" width="30">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Concerned Copy</pre>
                                                                <pre> Serial No.________   Date:____________</pre>
                                                                <!-- <p style="font-size:10px;font-weight:bold;text-align:center;">YOUR SERVICE IS OUR PRIDE
                                                                    SAFE AND SHOULD ALL PROUD <br></p> -->
                                                                   <p style="font-size:23px;font-weight:bold;text-align:center;">National Bank of Pakistan</p>

                                                                    <!-- <div class="uni"> -->
                                                                    <p style="font-size:10px;font-weight:bold;text-align:center;">QUAID-E-AWAM UNIVERSITY OF ENGINEERING <br>SCIENCE & TECHNOLOGY NAWABSHAH</p>
                                                                
                                                                    <p style="font-size:13px;font-weight:bold;text-align:center;">Please receive and credit to QUEST <br>
                                                                    Account No: <u>NIDA-11</u> -7  <br>Challan Fee: <br> Sig. & Stamp of Sectional Head
                                                                    (QUEST) </p>
                                           
                                                                    
                                                                    <!-- </div> -->
                                                                    <p style="font-size:15px;">
                                                                    &nbsp;Name: &nbsp;&nbsp;<b><?= $row['studentName']; ?></b><br>
                                                                    &nbsp;Father's Name:&nbsp;&nbsp;<b><?= $row['father']; ?></b><br>
                                                                    &nbsp;Roll No: &nbsp;&nbsp;<b><?= $row['seatNo']; ?></b><br>
                                                                    &nbsp;NIC No: &nbsp;&nbsp;<b><?= $row['nic']; ?></b><br>
                                                                    &nbsp;Cell No: &nbsp;&nbsp;<b><?= $row['cellNo']; ?></b>
                                                                    <br>&nbsp;Sig. Of Student:__________________________</p>


                                                                    <table border="1" align="center" width = "300" height = "180">
                                                                        <tr style="border:1px solid black;">
                                                                            <th>Examination Fees</th>
                                                                            <th>Amount</th>
                                                                        </tr>

                                                                        <tr style="border:1px solid black;">
                                                                            <td style="border:1px solid black;">1. Examination Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">2. Pass Marks Certificate Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">3. Degree Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">4. Transcript Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">5. Others</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">Total</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>
                                                                    </table>
                                                                    <p style= "font-size:15px;">&nbsp;Rupees...............................................................<br>
                                                                    &nbsp;(In words)............................................................</p>
                                                                <br>
                                                                <pre><b>CASHIER                     OFFICER</b></pre>

                                                                </td>

                                                                <!-- this is modified-->

                                                                 <!-- this is modified-->

                                                                 <td style="border:1px solid black;" width = "400">
                                                                <pre style="text-align:left">&nbsp<img src="img/nbplogo.png" width="30">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student's Copy</pre>
                                                                <pre> Serial No.________   Date:_____________</pre>
                                                                <!-- <p style="font-size:10px;font-weight:bold;text-align:center;">YOUR SERVICE IS OUR PRIDE
                                                                    SAFE AND SHOULD ALL PROUD <br></p> -->
                                                                   <p style="font-size:23px;font-weight:bold;text-align:center;">National Bank of Pakistan</p>

                                                                    <!-- <div class="uni"> -->
                                                                    <p style="font-size:10px;font-weight:bold;text-align:center;">QUAID-E-AWAM UNIVERSITY OF ENGINEERING <br>SCIENCE & TECHNOLOGY NAWABSHAH</p>
                                                                
                                                                    <p style="font-size:13px;font-weight:bold;text-align:center;">Please receive and credit to QUEST <br>
                                                                    Account No: <u>NIDA-11</u> -7  <br>Challan Fee: <br> Sig. & Stamp of Sectional Head
                                                                    (QUEST) </p>
                                           
                                                                    
                                                                    <!-- </div> -->
                                                                    <p style="font-size:15px;">
                                                                    &nbsp;Name: &nbsp;&nbsp;<b><?= $row['studentName']; ?></b><br>
                                                                    &nbsp;Father's Name:&nbsp;&nbsp;<b><?= $row['father']; ?></b><br>
                                                                    &nbsp;Roll No: &nbsp;&nbsp;<b><?= $row['seatNo']; ?></b><br>
                                                                    &nbsp;NIC No: &nbsp;&nbsp;<b><?= $row['nic']; ?></b><br>
                                                                    &nbsp;Cell No: &nbsp;&nbsp;<b><?= $row['cellNo']; ?></b>
                                                                    <br>&nbsp;Sig. Of Student:__________________________</p>


                                                                    <table border="1" align="center" width = "300" height = "180">
                                                                        <tr style="border:1px solid black;">
                                                                            <th>Examination Fees</th>
                                                                            <th>Amount</th>
                                                                        </tr>

                                                                        <tr style="border:1px solid black;">
                                                                            <td style="border:1px solid black;">1. Examination Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">2. Pass Marks Certificate Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">3. Degree Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">4. Transcript Fees</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">5. Others</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style="border:1px solid black;">Total</td>
                                                                            <td style="border:1px solid black;">Rs.</td>
                                                                        </tr>
                                                                    </table>
                                                                    <p style= "font-size:15px;">&nbsp;Rupees...............................................................<br>
                                                                    &nbsp;(In words)............................................................</p>
                                                                <br>
                                                                <pre><b>CASHIER                     OFFICER</b></pre>

                                                                </td>

                                                                <!-- this is modified-->

                                                           
                                                                
                                                            </tr>
                                                        </table>

                                                    </div> 

                                                        

                                                        <?php
                                                    }
                                                }
                                                ?>
                                                                                                          
                                             
            
                <br>
                <div class="text-center">
                          
                <script>
                    function PrintPage(){
                        window.print();
                    }
                  //  window.addEventListener('DOMContentLoaded',(event) => {
                    //    PrintPage()
                      //  setTimeout(function(){ window.close()}, 750)
                 //   });
                </script>
                    <button onclick="PrintPage()" class="btn btn-primary" id="print-btn">Print</button>

            
                </div>
           
    </div>
</body>
</html>