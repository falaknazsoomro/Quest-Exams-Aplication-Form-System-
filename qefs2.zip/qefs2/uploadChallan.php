<?php
if(isset($_POST['uploadBtn']))
{
    include ('connection.php');

sessionCheck();

$userId = $_SESSION['userID'];

$query = mysqli_query($conn, "SELECT * FROM students WHERE id = '$userId' LIMIT 1");

    $dataRow = mysqli_fetch_array($query);

    $accType = $dataRow['userType'];

    if($accType == 1)
    {
        header("location:challanPanel.php");
        exit();
    }



$rollNum = $_POST['rollNo'];
$challanNum = $_POST['challanNum'];
$verify = 0;

//upload challan image

 //print_r($_FILES["uploadedFile"]);
 $fileName = $_FILES["uploadfile"]["name"];
 $tempName = $_FILES["uploadfile"]["tmp_name"];
 $temp = explode(".", $_FILES["uploadfile"]["name"]);
 $newfilename = round(microtime(true)) . '.' . end($temp);
 $folderName = "uploadedChallans/" . $newfilename;


$sql = "INSERT INTO challan (id, rollNum, challanNum, challanImgUrl, verify) 
        VALUES('$userId', '$rollNum', '$challanNum', '$folderName', '$verify')";


$result = mysqli_query($conn,$sql) or die(mysql_error());

move_uploaded_file($tempName, $folderName);

if($result){
   // echo "Record Success";
    header("location:index.php");
    exit();
}
else
    echo "Sorry" . mysqli_error($conn);

mysqli_close($conn);

    

move_uploaded_file($tempName, $folderName);
}
else
{
    //echo ("Form Not Sumbitted");
    header("location:challanUpload.php");
    exit();
}

?>