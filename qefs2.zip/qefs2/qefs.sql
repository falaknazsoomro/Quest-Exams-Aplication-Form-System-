-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2023 at 09:15 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qefs`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `studentName` varchar(100) NOT NULL,
  `father` varchar(100) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `cellNo` varchar(15) NOT NULL,
  `seatNo` varchar(15) NOT NULL,
  `batch` varchar(10) NOT NULL,
  `enrollNo` varchar(20) NOT NULL,
  `department` varchar(20) NOT NULL,
  `dateOfAdmission` varchar(20) NOT NULL,
  `stYear` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `examType` varchar(50) NOT NULL,
  `examFees` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `studentName`, `father`, `surname`, `cellNo`, `seatNo`, `batch`, `enrollNo`, `department`, `dateOfAdmission`, `stYear`, `semester`, `examType`, `examFees`) VALUES
(1, 'Falak', 'Aftab Ahmed', 'Soomro', '03313132', '', '20', '', '', '', '', '', '', ''),
(2, 'Falak', 'Aftab Ahmed', 'Soomro', '03313132', '', '20', '', '', '', '', '', '', ''),
(3, 'Bhoongar', 'Aftab Ahmed', 'Soomro', '03313132', '30', '43', '', '', '', '', '', '', ''),
(4, 'Javed Ahmed', 'Allah Bux', 'Solangi', '03313132', '20KIT', '43', '5646', 'I.T', '', '', '344', 'Regular', '34344'),
(5, 'Javed Ahmed', 'Allah Bux', 'Solangi', '03313132', '20KIT', '43', '5646', 'I.T', '2009-12-31', '', '34', 'Regular', '34344'),
(6, 'Aftab Soomro', 'Naziruddin', 'Soomro', '09903490349034', '45', '345', '345', 'Information Technolo', '2023-01-01', '', '123', 'Regular', '355454'),
(7, 'Aftab Soomro', 'Naziruddin', 'Soomro', '09903490349034', '45', '345', '345', 'Information Technolo', '', '', '123', 'Regular', '355454'),
(8, 'Aftab Soomro', 'Naziruddin', 'Soomro', '09903490349034', '45', '345', '345', 'Information Technolo', '', '', '123', 'Regular', '355454'),
(9, 'Aftab Soomro1', 'Naziruddin1', 'Soomro1', '099034903490341', '451', '3451', '3451', 'Information Technolo', '2023-12-31', '', '123', 'supply', '3554541'),
(10, 'Falak Naz', 'Aftab Ahmed', 'Soomro', '030265585', '20IT06', '20', '555', 'I.T', '2023-04-29', '', '5th', 'Suppliment', '2000'),
(11, 'Falak Naz', 'Aftab Ahmed', 'Soomro', '030265585', '20IT06', '20', '555', 'I.T', '2023-04-29', '', '5th', 'Regular', '2000'),
(12, 'Falak Naz', 'Aftab Ahmed', 'Soomro', '030265585', '20IT06', '20', '555', 'I.T', '2023-04-29', '', '5th', 'Supplimentary', '2000'),
(13, 'Falak Naz', 'Aftab Ahmed', 'Soomro', '030265585', '20IT06', '20', '555', 'I.T', '2023-04-29', '', '5th', 'Supplimentary', '2000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
