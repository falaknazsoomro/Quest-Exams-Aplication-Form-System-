<?php
include ('connection.php');

sessionCheck();

$userId = $_SESSION['userID'];

$query1 = mysqli_query($conn, "SELECT * FROM students WHERE id = '$userId' LIMIT 1");

$dataRow = mysqli_fetch_array($query1);

$userType = $dataRow['userType'];

if($userType == 0)
{
    header("location:index.php");
    exit();
}

$verfiedStatus = 0;

$query = mysqli_query($conn, "SELECT * FROM challan");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script
        src="https://code.jquery.com/jquery-3.6.4.js"
        integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E="
        crossorigin="anonymous">
    </script>
    <script>
        $(document).ready(function(e){
            
            
            function approval(id){
                //alert(id);
                $.post("approval.php",
                {
                    pId: id
                },
                function(data,status){
                    //alert("Data: " + data + ", Status: " + status);
                    if(status == "success")
                    {
                        //alert(id);;
                        //$('#id'+ id).css({"background-color": "Green", "color": "white"});
                        $('#id'+ data).removeClass("appButt");
                        $('#id'+ data).addClass("approved");
                        $('#id'+ data).html("Approved");

                    }
                });
            }
            $(document).on('click', '.appButt', function(e){
                var challanId = $(this).attr('id');
                var finalChId = challanId.substring(2);
                var status = finalChId.substr(finalChId.length-1,1);
                finalChId = finalChId.substr(0, finalChId.length-1);
                //alert("ID = " + finalChId + ", Verification = " + status);
                //alert(challanId);
                approval(finalChId);
            });
            /*$('.appButt').live('click', function(){
                alert("Hello World!");
            });
            
            $('.appButt').click(function(){
                alert("The paragraph was clicked.");
            });
            .live('click', function(){
                alert();
            });*/
        });
    </script>
    <style>
        body{
            padding: 0;
            margin: 0;
            background-color: azure;
        }
        .mainCenter{
            width: 1200px;
            margin: 0 auto;
        }
        .mainCenter table{
            width: 100%;
        }
        .mainCenter table tr td{
            border: 1px solid red;
            padding: 0;
        }

        .approved{
            background-color: green;
            color: white;
            border: 2px solid rgb(4, 99, 4);
        }

        .row img{
            width:150px;
            height:150px;
            object-fit:cover;
        }
    </style>

    <title>Document</title>
</head>
<body>
    <div class="mainCenter">
        <div class="tableContainer">
            <table>
                <tr>
                    <td>No.</td>
                    <td>Roll #</td>
                    <td>Challan No</td>
                    <td>Image</td>
                    <td>Dated</td>
                    <td>Options</td>
                </tr>
                <?php
                $intNum = 1;

                while($dataRow = mysqli_fetch_array($query)){
                    
                    $challanId = $dataRow['challanId'];
                    $userId = $dataRow['id'];
                    $rollNo = $dataRow['rollNum'];
                    $challanNo = $dataRow['challanNum'];
                    $challanImg = $dataRow['challanImgUrl'];
                    $uploadDate = $dataRow['updloadDate'];
                    $verify = $dataRow['verify'];
                    

                    if($verify == 1)
                    {
                        echo('<tr class="row">
                            <td>'.$intNum.'</td>
                            <td>'.$rollNo.'</td>
                            <td>'.$challanNo.'</td>
                            <td><img src="'.$challanImg.'" width="50" /></td>
                            <td>'.$uploadDate.'</td>
                            <td><button id="id'.$challanId.$verify.'" class="approved">Approved</button></td>
                        </tr>');
                        
                    }

                    else
                    {
                        echo('<tr class="row">
                            <td>'.$intNum.'</td>
                            <td>'.$rollNo.'</td>
                            <td>'.$challanNo.'</td>
                            <td><img src="'.$challanImg.'" width="50" /></td>
                            <td>'.$uploadDate.'</td>
                            <td><button id="id'.$challanId.$verify.'" class="appButt">Approve</button></td>
                        </tr>');
                    }
                    
                    $intNum++;
                } 
                ?>
            </table>
        </div>
    </div>
</body>
</html>