<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<script src="js/html2pdfbundle.js"></script>-->
    <script src="https://raw.githack.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js"></script>
    <script src="js/pdf.js"></script>
    <style>
        body{
            font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }
        #mainCenter{
          
           /* display: block; */
            /*background-color: red; */
            padding: 0 auto;
            margin: 0 auto;
        }
        .challanContainer{
           /* background-color: yellow; */
            width: 11.68in;
            display: block;
            padding: 10px;
        }
        .singlePortion{
            display: block;
            float: left;
            border-right: 2px dotted #bababa;
            padding: 5px;
            width: 2.79in;
            font-family: monospace;
        }
        .clearCont{
            clear: both;
        }

      

      

    </style>
    <title>Document</title>
</head>
<body id="body">


                        <div id="myForm">
                        <form action="" method="POST">
                        <input type="text" name="id" placeholder="Enter Student Id" />
                        <input type="submit" name="search" value="Search by Id">

                        

                                        <?php 
                                                include ('connection.php');

                                                $query = "SELECT * FROM students";
                                                $query_run = mysqli_query($conn,$query);

                                                if(isset($_POST['search']))
                                                {
                                                    $id = $_POST['id'];

                                                    $query = "SELECT * FROM students where id='$id'";
                                                    $query_run = mysqli_query($conn,$query);

                                                    while($row = mysqli_fetch_array($query_run))
                                                    {
                                        ?>






    <div id="mainCenter">
        <div class="challanContainer">
            <div class="singlePortion">
                <table  width="100%">
                    <tr>
                        <td align="left"><img src="img/nbplogo.png" width="30"></td>
                        <td align="right">Concerned Copy</td>
                    </tr>

                    <tr>
                        <td align="left"><br>Serial No._______</td>
                        <td align="right"><br>Date:________</td>
                        
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 16px;"><center><br><br><b>National Bank of Pakistan</b><br><br></center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>QUAID-E-AWAM UNIVERSITY OF ENGINEERING SCIENCE & TECHNOLOGY NAWABSHAH</center></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center><br><br>Please receive and credit to QUEST</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Account No: NIDA-11 -7</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Challan Fees</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Sig. & Stamp of Sectional Head (QUEST)</center><br><br></td>
                    </tr>


                    <tr>
                        <td style="font-size: 12px;"><b>Name:</b></td>
                        <td style="font-size: 12px;"><b><b><?= $row['studentName']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Father's Name:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['father']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>Roll No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['seatNo']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>NIC No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['nic']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Cell No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['cellNo']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Signature of Student:</b></td>
                        <td style="font-size: 12px;"><b>_________________</b><br><br></td>
                    </tr>

                    <tr>
                        <td></td>
                    </tr>
                    <tr><td colspan="2">
                        <div class="feeStructure">
                            <table align="left" border="1" width="100%">
                                <tr>
                                    <td align="left" style="font-size: 12px;">Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Amount</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">1.Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">2.Pass Marks Certificate Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">3.Degree Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">4.Transcript Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">5.Others</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">Total</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>                                 
                            </table>
                        </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;" colspan="2"><br>Rupees in words: _____________________ <br><br> ______________________________________<br><br><br><br><br><br></td>
                    </tr>
                    <tr>
                        <td align="left" style="font-size: 14px;"><r<b>CASHIER</b></td>
                        <td align="right" style="font-size: 14px;"><b>OFFICER</b></td>
                        
                    </tr>
                </table>
            </div>

            <div class="singlePortion">
                <table  width="100%">
                    <tr>
                        <td align="left"><img src="img/nbplogo.png" width="30"></td>
                        <td align="right">Concerned Copy</td>
                    </tr>

                    <tr>
                        <td align="left"><br>Serial No._______</td>
                        <td align="right"><br>Date:________</td>
                        
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 16px;"><center><br><br><b>National Bank of Pakistan</b><br><br></center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>QUAID-E-AWAM UNIVERSITY OF ENGINEERING SCIENCE & TECHNOLOGY NAWABSHAH</center></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center><br><br>Please receive and credit to QUEST</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Account No: NIDA-11 -7</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Challan Fees</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Sig. & Stamp of Sectional Head (QUEST)</center><br><br></td>
                    </tr>


                    <tr>
                        <td style="font-size: 12px;"><b>Name:</b></td>
                        <td style="font-size: 12px;"><b><b><?= $row['studentName']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Father's Name:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['father']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>Roll No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['seatNo']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>NIC No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['nic']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Cell No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['cellNo']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Signature of Student:</b></td>
                        <td style="font-size: 12px;"><b>_________________</b><br><br></td>
                    </tr>

                    <tr>
                        <td></td>
                    </tr>
                    <tr><td colspan="2">
                        <div class="feeStructure">
                            <table align="left" border="1" width="100%">
                                <tr>
                                    <td align="left" style="font-size: 12px;">Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Amount</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">1.Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">2.Pass Marks Certificate Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">3.Degree Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">4.Transcript Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">5.Others</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">Total</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>                                 
                            </table>
                        </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;" colspan="2"><br>Rupees in words: _____________________ <br><br> ______________________________________<br><br><br><br><br><br></td>
                    </tr>
                    <tr>
                        <td align="left" style="font-size: 14px;"><r<b>CASHIER</b></td>
                        <td align="right" style="font-size: 14px;"><b>OFFICER</b></td>
                        
                    </tr>
                </table>
            </div>

            <div class="singlePortion">
                <table  width="100%">
                    <tr>
                        <td align="left"><img src="img/nbplogo.png" width="30"></td>
                        <td align="right">Concerned Copy</td>
                    </tr>

                    <tr>
                        <td align="left"><br>Serial No._______</td>
                        <td align="right"><br>Date:________</td>
                        
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 16px;"><center><br><br><b>National Bank of Pakistan</b><br><br></center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>QUAID-E-AWAM UNIVERSITY OF ENGINEERING SCIENCE & TECHNOLOGY NAWABSHAH</center></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center><br><br>Please receive and credit to QUEST</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Account No: NIDA-11 -7</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Challan Fees</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Sig. & Stamp of Sectional Head (QUEST)</center><br><br></td>
                    </tr>


                    <tr>
                        <td style="font-size: 12px;"><b>Name:</b></td>
                        <td style="font-size: 12px;"><b><b><?= $row['studentName']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Father's Name:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['father']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>Roll No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['seatNo']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>NIC No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['nic']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Cell No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['cellNo']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Signature of Student:</b></td>
                        <td style="font-size: 12px;"><b>_________________</b><br><br></td>
                    </tr>

                    <tr>
                        <td></td>
                    </tr>
                    <tr><td colspan="2">
                        <div class="feeStructure">
                            <table align="left" border="1" width="100%">
                                <tr>
                                    <td align="left" style="font-size: 12px;">Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Amount</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">1.Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">2.Pass Marks Certificate Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">3.Degree Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">4.Transcript Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">5.Others</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">Total</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>                                 
                            </table>
                        </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;" colspan="2"><br>Rupees in words: _____________________ <br><br> ______________________________________<br><br><br><br><br><br></td>
                    </tr>
                    <tr>
                        <td align="left" style="font-size: 14px;"><r<b>CASHIER</b></td>
                        <td align="right" style="font-size: 14px;"><b>OFFICER</b></td>
                        
                    </tr>
                </table>
            </div>

            <div class="singlePortion" style="border:none;">
                <table  width="100%">
                    <tr>
                        <td align="left"><img src="img/nbplogo.png" width="30"></td>
                        <td align="right">Concerned Copy</td>
                    </tr>

                    <tr>
                        <td align="left"><br>Serial No._______</td>
                        <td align="right"><br>Date:________</td>
                        
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 16px;"><center><br><br><b>National Bank of Pakistan</b><br><br></center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>QUAID-E-AWAM UNIVERSITY OF ENGINEERING SCIENCE & TECHNOLOGY NAWABSHAH</center></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center><br><br>Please receive and credit to QUEST</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Account No: NIDA-11 -7</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Challan Fees</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Sig. & Stamp of Sectional Head (QUEST)</center><br><br></td>
                    </tr>


                    <tr>
                        <td style="font-size: 12px;"><b>Name:</b></td>
                        <td style="font-size: 12px;"><b><b><?= $row['studentName']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Father's Name:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['father']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>Roll No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['seatNo']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>NIC No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['nic']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Cell No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['cellNo']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Signature of Student:</b></td>
                        <td style="font-size: 12px;"><b>_________________</b><br><br></td>
                    </tr>

                    <tr>
                        <td></td>
                    </tr>
                    <tr><td colspan="2">
                        <div class="feeStructure">
                            <table align="left" border="1" width="100%">
                                <tr>
                                    <td align="left" style="font-size: 12px;">Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Amount</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">1.Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">2.Pass Marks Certificate Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">3.Degree Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">4.Transcript Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">5.Others</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">Total</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>                                 
                            </table>
                        </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;" colspan="2"><br>Rupees in words: _____________________ <br><br> ______________________________________<br><br><br><br><br><br></td>
                    </tr>
                    <tr>
                        <td align="left" style="font-size: 14px;"><r<b>CASHIER</b></td>
                        <td align="right" style="font-size: 14px;"><b>OFFICER</b></td>
                        
                    </tr>
                </table>
            </div>

            <div class="clearCont"></div>
            
                
        </div>
    </div>

                                <?php
                                       }
                                        }
                                ?>

            

    </form>
                            
    </div>

    <script>
                    function PrintPage(){

                        var body = document.getElementById('body').innerHTML;
                        var  mainCenter = document.getElementById('mainCenter').innerHTML;

                        document.getElementById('body').innerHTML = mainCenter;

                        window.print();

                        document.getElementById('body').innerHTML = body;
                    }
                  //  window.addEventListener('DOMContentLoaded',(event) => {
                    //    PrintPage()
                      //  setTimeout(function(){ window.close()}, 750)
                 //   });
                </script>
                    <button onclick="PrintPage()" class="btn btn-primary" id="print-btn">Print</button>
    
</body>
</html>