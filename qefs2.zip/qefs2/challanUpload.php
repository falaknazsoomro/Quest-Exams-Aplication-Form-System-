<?php

include ('connection.php');

sessionCheck();

$userId = $_SESSION['userID'];

$query = mysqli_query($conn, "SELECT * FROM students WHERE id = '$userId' LIMIT 1");

    $dataRow = mysqli_fetch_array($query);

    $accType = $dataRow['userType'];

    if($accType == 1)
    {
        header("location:challanPanel.php");
        exit();
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div>
    <form method="POST" action="uploadChallan.php" enctype="multipart/form-data">
                <div>
                    <label>ROLL # <input type="text" name="rollNo" /></lable>
                </div>
                <div>
                    <label>Challan # <input type="text" name="challanNum" /></lable>
                </div>
                <div class="upload-wrapper">
                <span class="file-name">Choose a file...</span>
                <label for="file-upload">Browse<input type="file" id="file-upload" name="uploadfile"></label>
                </div>
                <input type="submit" name="uploadBtn" value="Upload" />
            </form>
    </div>
</body>
</html>