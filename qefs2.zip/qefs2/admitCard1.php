<?php 

include ('connection.php');

sessionCheck();

$userId = $_SESSION['userID'];

$query = mysqli_query($conn, "SELECT * FROM students WHERE id = '$userId' LIMIT 1");

while($dataRow = mysqli_fetch_array($query)){
    $stName1 = $dataRow['studentName'];
    $father1 = $dataRow['father'];
    $surname = $dataRow['surname'];
    $email1 =$dataRow['email'];
    $nic1 = $dataRow['nic'];
    $examType = $dataRow['examType'];
    $semester = $dataRow['semester'];
    $seatNo = $dataRow['seatNo'];
    $batch = $dataRow['batch'];
    $enrollNo = $dataRow['enrollNo'];
    $cellNo = $dataRow['cellNo'];
    $department = $dataRow['department'];
    $examFees = $dataRow['examFees'];
    $sub1 = $dataRow['sub1'];
    $sub2 = $dataRow['sub2'];
    $sub3 = $dataRow['sub3'];
    $sub4 = $dataRow['sub4'];
    $sub5 = $dataRow['sub5'];
    $sub6 = $dataRow['sub6'];
    $sub7 = $dataRow['sub7'];
    $sub8 = $dataRow['sub8'];
    $sub9 = $dataRow['sub9'];
    $sub10 = $dataRow['sub10'];
    $profileUrl = $dataRow['profile_url'];


   // $profileUrl = $dataRow['profile_url'];
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

     <!--<script src="js/html2pdfbundle.js"></script>-->
     <script src="https://raw.githack.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js"></script>
    <script src="js/pdf.js"></script>

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Online Examination System</title>

    
  </head>
  <body id="body">

  <div class="container-fluid">
    <div class="row">

    <div class="col-md-2">

  <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: black;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="<?php echo($profileUrl);?>" width="50">
    <br><?php echo $stName1; ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">My Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="challanUpdated1.php">Download Challan</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="challnUpload1.php">Upload Challan</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="admitCard1.php">Download Slip</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>
       
      </ul>
      
    </div>
  </div>
</nav>
</div>

<div class="col-md-10">

<div class="container">

<br>

            <h3><center>Admit Card</center></h3>
        <table width="95%" align="center">
        
            <tr>
                <td style="text-align:left;">Regular / Supplimentary Examination of &nbsp;&nbsp;&nbsp;<b><u><?php echo $examType; ?></u></b></td>
                <td style="text-align=left;">Term / Semester &nbsp;&nbsp;&nbsp; <b><u><?php echo $semester; ?></u></b></td>
                
            </tr>
            <tr>
                <td>Name&nbsp;&nbsp;&nbsp;<b><u><?php echo $stName1; ?></u></b></td>
                <td>ID/Seat No.&nbsp;&nbsp;&nbsp;<b><u><?php echo $seatNo; ?></u></b></td>
                <td colspan="4"><img src="<?php echo $profileUrl ?>" alt="" width="100" height="100"></td>
            </tr>

            <tr>
                <td>Father's Name: &nbsp;&nbsp;&nbsp;<b><u><?php echo $father1; ?></u></b></td>
                <td>Batch: &nbsp;&nbsp;&nbsp;<b><u><?php echo $batch; ?></u></b></td>
                
            </tr>

            <tr>
                <td>Surname: &nbsp;&nbsp;&nbsp;<b><u><?php echo $surname; ?></u></b></td>
                <td>Enroll No: &nbsp;&nbsp;&nbsp;<b><u><?php echo $enrollNo; ?></u></b></td>
                
            </tr>

            <tr>
                <td>Cell No: &nbsp;&nbsp;&nbsp;<b><u><?php echo $cellNo; ?></u></b></td>
                <td>Department: &nbsp;&nbsp;&nbsp;<b><u><?php echo $department; ?></u></b></td>
                
                
            </tr>

        </table>

        <br>
        <br>
        <h6>I wish to appear in the following subjects</h6>

            <br>

            <div class="myTable">

            <table width="95%" text-align="center">
                <tr>

                    <th style="text-align:center; border:1px;">1</th>
                    <td><b><u><?php echo $sub1; ?></u></b></td>

                    <th style="text-align:center;">2</th>
                    <td><b><u><?php echo $sub2; ?></u></b></td>

                </tr>

                <tr>

                    <th style="text-align:center;">3</th>
                    <td><b><u><?php echo $sub3; ?></u></b></td>

                    <th style="text-align:center;">4</th>
                    <td><b><u><?php echo $sub4; ?></u></b></td>

                </tr>


                <tr>

                    <th style="text-align:center;">5</th>
                    <td><b><u><?php echo $sub5; ?></u></b></td>

                    <th style="text-align:center;">6</th>
                    <td><b><u><?php echo $sub6 ?></u></b></td>

                </tr>

                <tr>

                    <th style="text-align:center;">7</th>
                    <td><b><u><?php echo $sub7; ?></u></b></td>

                    <th style="text-align:center;">8</th>
                    <td><b><u><?php echo $sub8; ?></u></b></td>

                </tr>

                <tr>

                    <th style="text-align:center;">9</th>
                    <td><b><u><?php echo $sub9; ?></u></b></td>

                    <th style="text-align:center;">10</th>
                    <td><b><u><?php echo $sub10; ?></u></b></td>

                </tr>

            </table>
    </div>

</div>



<script>
                    function PrintPage(){

                        
                        window.print();

                       
                    }
                  //  window.addEventListener('DOMContentLoaded',(event) => {
                    //    PrintPage()
                      //  setTimeout(function(){ window.close()}, 750)
                 //   });
                </script>
                    <button onclick="PrintPage()" class="btn btn-primary" id="print-btn">Print</button>

                    <br>
                    </div>

  </body>
</html>

<?php
if (isset($_POST['uploadBtn']) && $_POST['uploadBtn'] == 'Upload') {
    
    //print_r($_FILES["uploadedFile"]);
    $fileName = $_FILES["uploadfile"]["name"];
    $tempName = $_FILES["uploadfile"]["tmp_name"];
    $temp = explode(".", $_FILES["uploadfile"]["name"]);
    $newfilename = round(microtime(true)) . '.' . end($temp);
    $folderName = "profileUpload/" . $newfilename;

    $sqlProfileImg = "UPDATE students SET profile_url='$folderName' WHERE
            id='$userId'";


    $result = mysqli_query($conn,$sqlProfileImg) or die(mysqli_error());

    if($result){
        echo "Record Success";
    }else
        echo "Sorry" . mysqli_error($conn);
    

    

    move_uploaded_file($tempName, $folderName);
}

if(isset($_POST['sub'])){

$userId1 = $userId;

$stName = $_POST['studentName'];
$father = $_POST['father'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$nic = $_POST['nic'];
$cellNo = $_POST['cellNo'];
$seatNo = $_POST['seatNo'];
$batch = $_POST['batch'];
$enrollNo = $_POST['enrollNo'];
$department = $_POST['department'];
$dateOfAdmission = $_POST['dateOfAdmission'];
$stYear = $_POST['stYear'];
$semester = $_POST['semester'];
$examType = $_POST['examType'];
$examFees = $_POST['examFees'];
$sub1 = $_POST['sub1'];
$sub2 = $_POST['sub2'];
$sub3 = $_POST['sub3'];
$sub4 = $_POST['sub4'];
$sub5 = $_POST['sub5'];
$sub6 = $_POST['sub6'];
$sub7 = $_POST['sub7'];
$sub8 = $_POST['sub8'];
$sub9 = $_POST['sub9'];
$sub10 = $_POST['sub10'];

//$conn = mysqli_connect('localhost','root','','qefs');

//$sql = mysqli_query("INSERT INTO students (studentName,father,surname,nic,cellNo, seatNo, batch, enrollNo,department,dateOfAdmission,semester,examType,examFees) 
  //                                         VALUES('$stName','$father','$surname','$nic','$cellNo', '$seatNo', '$batch','$enrollNo','$department','$dateOfAdmission','$semester','$examType','$examFees')");

$sql = "UPDATE students SET studentName='$stName',father='$father',surname='$surname',email='$email',nic='$nic',cellNo='$cellNo', seatNo='$seatNo', batch='$batch', enrollNo='$enrollNo',department='$department',dateOfAdmission='$dateOfAdmission',stYear='$stYear', semester='$semester',examType='$examType',examFees='$examFees',sub1='$sub1',sub2='$sub2',sub3='$sub3',sub4='$sub4',sub5='$sub5',sub6='$sub6',sub7='$sub7',sub8='$sub8',sub9='$sub9',sub10='$sub10' WHERE
            id='$userId1'";


$result = mysqli_query($conn,$sql);

if($result){
    echo "Record Success";
}else
    echo "Sorry" . mysqli_error($conn);
}



mysqli_close($conn);



?>
