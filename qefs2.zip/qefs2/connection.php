<?php 
session_start();

$conn = mysqli_connect('localhost','root','','qefs2');
if($conn){
     echo "";
}
else{
    echo "Could not connect";
}

function sessionCheck(){
    if(!isset($_SESSION['userID'])){
        header("location:login.php");
    }
   // else{
        //header("location:indexboot1.php");
     //   echo $_SESSION
   // }
}


?>