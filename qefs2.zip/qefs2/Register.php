<?php 

include ('connection.php');

if(isset($_POST['sub'])){

$stName = $_POST['studentName'];
$father = $_POST['father'];
$email = $_POST['email'];
$password1 = $_POST['password1'];
$conPassword1 = $_POST['conPassword1'];

//$conn = mysqli_connect('localhost','root','','qefs');

//$sql = mysqli_query("INSERT INTO students (studentName,father,surname,nic,cellNo, seatNo, batch, enrollNo,department,dateOfAdmission,semester,examType,examFees) 
  //                                         VALUES('$stName','$father','$surname','$nic','$cellNo', '$seatNo', '$batch','$enrollNo','$department','$dateOfAdmission','$semester','$examType','$examFees')");

$sql = "INSERT INTO students (studentName,father,email,password1,conPassword1) 

                                           VALUES('$stName','$father','$email','$password1','$conPassword1')";


$result = mysqli_query($conn,$sql);

if($result){
    echo "Record Success";
}else
    echo "Sorry" . mysqli_error($conn);
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register </title>
  <link href="css/1bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
  <style>

  </style>
</head>

<body>
  <header>
    <div class="container  ">
      <div class="row p-2 ">
        <div class="col-3 ">
          <div class=""><img src="logo.jpg" alt="Questlogo" srcset="" class="img-thumbnail vlign-top h-75 border-0">
          </div>
        </div>
        <div class="col-9 ">
          <div class="mt-5 ms-5">
            <h2 class=" fs-2 "><centre>QUAID-E-AWAM UNIVERSITY</centre></h1>
              <h6 class="ms-2"><centre>OF ENGINEERING, SCIENCE & TECHNOLOGY</centre>
            </h2>
            <h5 class="ms-5">NAWABSHAH, SINDH, PAKISTAN</h5>

          </div>

        </div>

      </div>
      
    </div>
 
  </header>
  <hr>
  <div class="container d-flex justify-content-center">
 
    <form method="post">

      <div class="mb-3 d-flex justify-content-center"><h1>Register Form</h1></div>
      <div class="row ">
        
        <div class="col-6 d-flex ">
          <div class="form-outline mb-4">

            <input type="text" id="studentName" name="studentName" class="form-control shadow" placeholder="Student Name" />

          </div>

        </div>
        <div class="col-6">
          <div class="form-outline mb-4   ">

            <input type="text" id="father" name="father" class="form-control shadow " placeholder="Father's Name" />

          </div>
        </div>

      </div>
      <div class="row">
        <div class="col-12">
          <div class="form-outline mb-4">
            <input type="email" id="Email" name="email" class="form-control shadow " placeholder="Email" />

          </div>
 <div class="form-outline mb-4">
            <input type="text" id="Nic" name="nic" class="form-control shadow " placeholder="NIC No" />

          </div>
        </div>
      </div>



      <div class="row ">
        <div class="col-6 d-flex ">
          <div class="form-outline mb-4">
            <input type="password" id="password1" name="password1" class="form-control shadow" placeholder="Password" />

          </div>

        </div>
        <div class="col-6">
          <div class="form-outline mb-5">
            <input type="password" id="conPassword1" name="conPassword1" class="form-control shadow" placeholder="Confirm Password" />

          </div>
        </div>

      </div>
      <div class="d-flex justify-content-center">

      

        <input type="submit" name="sub" class="btn btn-primary btn-block btn-lg gradient-custom-4 w-50 " value="Register">
        
      </div>

      <p class="text-center text-muted mt-4 ">Have already an account? <a href="Login.php"
          class="fw-bold text-body"><u>Login here</u></a></p>

    </form>


  </div>
</body>

</html>