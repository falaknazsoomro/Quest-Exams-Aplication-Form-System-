<?php 

include ('connection.php');

sessionCheck();

$userId = $_SESSION['userID'];

$query = mysqli_query($conn, "SELECT * FROM students WHERE id = '$userId' LIMIT 1");

    $dataRow = mysqli_fetch_array($query);

    $accType = $dataRow['userType'];

    if($accType == 1)
    {
        header("location:challanPanel.php");
        exit();
    }

    $stName1 = $dataRow['studentName'];
    $father1 = $dataRow['father'];
    $surname1 = $dataRow['surname'];
    $email1 =$dataRow['email'];
    $nic1 = $dataRow['nic'];
    $profileUrl = $dataRow['profile_url'];
   

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

     <!--<script src="js/html2pdfbundle.js"></script>-->
     <script src="https://raw.githack.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js"></script>
    <script src="js/pdf.js"></script>

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Online Examination System</title>

    <style>

        table, th, td {
        border: 1px solid black;
        }

        .navbar-brand img{
            width:70px;
            height:70px;
            border-radius:50%;
            border:2px solid white;
        }

        #mainCenter{
          
          /* display: block; */
           /*background-color: red; */
           padding: 0 auto;
           margin: 0 auto;
       }
       .challanContainer{
          /* background-color: yellow; */
           width: 11.68in;
           display: block;
           padding: 10px;
       }
       .singlePortion{
           display: block;
           float: left;
           border-right: 2px dotted #bababa;
           padding: 5px;
           width: 2.79in;
           font-family: monospace;
       }
       .clearCont{
           clear: both;
       }

    </style>
  </head>
  <body id="body">

  <div class="container-fluid">
    <div class="row">

    <div class="col-md-2">

  <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: black;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="<?php echo($profileUrl);?>" width="50">
    <br><?php echo $stName1; ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">My Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="challanUpdated1.php">Download Challan</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="challanUpload1.php">Upload Challan</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="admitCard1.php">Download Slip</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>
       
      </ul>
      
    </div>
  </div>
</nav>
</div>

<div class="col-md-10">

<div class="container">

                <div id="myForm">
                        <form action="" method="POST">
                        <input type="text" name="id" placeholder="Enter Student Id" />
                        <input type="submit" name="search" value="Search by Id">

                        

                                        <?php 
                                              //  include ('connection.php');

                                                $query = "SELECT * FROM students";
                                                $query_run = mysqli_query($conn,$query);

                                                if(isset($_POST['search']))
                                                {
                                                    $id = $_POST['id'];

                                                    $query = "SELECT * FROM students where id='$id'";
                                                    $query_run = mysqli_query($conn,$query);

                                                    while($row = mysqli_fetch_array($query_run))
                                                    {
                                        ?>






    <div id="mainCenter">
        <div class="challanContainer">
            <div class="singlePortion">
                <table  width="100%">
                    <tr>
                        <td align="left"><img src="img/nbplogo.png" width="30"></td>
                        <td align="right">Concerned Copy</td>
                    </tr>

                    <tr>
                        <td align="left"><br>Serial No._______</td>
                        <td align="right"><br>Date:________</td>
                        
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 16px;"><center><br><br><b>National Bank of Pakistan</b><br><br></center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>QUAID-E-AWAM UNIVERSITY OF ENGINEERING SCIENCE & TECHNOLOGY NAWABSHAH</center></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center><br><br>Please receive and credit to QUEST</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Account No: NIDA-11 -7</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Challan Fees</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Sig. & Stamp of Sectional Head (QUEST)</center><br><br></td>
                    </tr>


                    <tr>
                        <td style="font-size: 12px;"><b>Name:</b></td>
                        <td style="font-size: 12px;"><b><b><?= $row['studentName']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Father's Name:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['father']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>Roll No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['seatNo']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>NIC No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['nic']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Cell No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['cellNo']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Signature of Student:</b></td>
                        <td style="font-size: 12px;"><b>_________________</b><br><br></td>
                    </tr>

                    <tr>
                        <td></td>
                    </tr>
                    <tr><td colspan="2">
                        <div class="feeStructure">
                            <table align="left" border="1" width="100%">
                                <tr>
                                    <td align="left" style="font-size: 12px;">Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Amount</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">1.Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">2.Pass Marks Certificate Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">3.Degree Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">4.Transcript Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">5.Others</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">Total</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>                                 
                            </table>
                        </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;" colspan="2"><br>Rupees in words: _____________________ <br><br> ______________________________________<br><br><br><br><br><br></td>
                    </tr>
                    <tr>
                        <td align="left" style="font-size: 14px;"><r<b>CASHIER</b></td>
                        <td align="right" style="font-size: 14px;"><b>OFFICER</b></td>
                        
                    </tr>
                </table>
            </div>

            <div class="singlePortion">
                <table  width="100%">
                    <tr>
                        <td align="left"><img src="img/nbplogo.png" width="30"></td>
                        <td align="right">Concerned Copy</td>
                    </tr>

                    <tr>
                        <td align="left"><br>Serial No._______</td>
                        <td align="right"><br>Date:________</td>
                        
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 16px;"><center><br><br><b>National Bank of Pakistan</b><br><br></center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>QUAID-E-AWAM UNIVERSITY OF ENGINEERING SCIENCE & TECHNOLOGY NAWABSHAH</center></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center><br><br>Please receive and credit to QUEST</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Account No: NIDA-11 -7</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Challan Fees</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Sig. & Stamp of Sectional Head (QUEST)</center><br><br></td>
                    </tr>


                    <tr>
                        <td style="font-size: 12px;"><b>Name:</b></td>
                        <td style="font-size: 12px;"><b><b><?= $row['studentName']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Father's Name:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['father']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>Roll No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['seatNo']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>NIC No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['nic']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Cell No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['cellNo']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Signature of Student:</b></td>
                        <td style="font-size: 12px;"><b>_________________</b><br><br></td>
                    </tr>

                    <tr>
                        <td></td>
                    </tr>
                    <tr><td colspan="2">
                        <div class="feeStructure">
                            <table align="left" border="1" width="100%">
                                <tr>
                                    <td align="left" style="font-size: 12px;">Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Amount</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">1.Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">2.Pass Marks Certificate Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">3.Degree Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">4.Transcript Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">5.Others</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">Total</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>                                 
                            </table>
                        </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;" colspan="2"><br>Rupees in words: _____________________ <br><br> ______________________________________<br><br><br><br><br><br></td>
                    </tr>
                    <tr>
                        <td align="left" style="font-size: 14px;"><r<b>CASHIER</b></td>
                        <td align="right" style="font-size: 14px;"><b>OFFICER</b></td>
                        
                    </tr>
                </table>
            </div>

            <div class="singlePortion">
                <table  width="100%">
                    <tr>
                        <td align="left"><img src="img/nbplogo.png" width="30"></td>
                        <td align="right">Concerned Copy</td>
                    </tr>

                    <tr>
                        <td align="left"><br>Serial No._______</td>
                        <td align="right"><br>Date:________</td>
                        
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 16px;"><center><br><br><b>National Bank of Pakistan</b><br><br></center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>QUAID-E-AWAM UNIVERSITY OF ENGINEERING SCIENCE & TECHNOLOGY NAWABSHAH</center></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center><br><br>Please receive and credit to QUEST</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Account No: NIDA-11 -7</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Challan Fees</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Sig. & Stamp of Sectional Head (QUEST)</center><br><br></td>
                    </tr>


                    <tr>
                        <td style="font-size: 12px;"><b>Name:</b></td>
                        <td style="font-size: 12px;"><b><b><?= $row['studentName']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Father's Name:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['father']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>Roll No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['seatNo']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>NIC No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['nic']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Cell No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['cellNo']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Signature of Student:</b></td>
                        <td style="font-size: 12px;"><b>_________________</b><br><br></td>
                    </tr>

                    <tr>
                        <td></td>
                    </tr>
                    <tr><td colspan="2">
                        <div class="feeStructure">
                            <table align="left" border="1" width="100%">
                                <tr>
                                    <td align="left" style="font-size: 12px;">Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Amount</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">1.Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">2.Pass Marks Certificate Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">3.Degree Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">4.Transcript Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">5.Others</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">Total</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>                                 
                            </table>
                        </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;" colspan="2"><br>Rupees in words: _____________________ <br><br> ______________________________________<br><br><br><br><br><br></td>
                    </tr>
                    <tr>
                        <td align="left" style="font-size: 14px;"><r<b>CASHIER</b></td>
                        <td align="right" style="font-size: 14px;"><b>OFFICER</b></td>
                        
                    </tr>
                </table>
            </div>

            <div class="singlePortion" style="border:none;">
                <table  width="100%">
                    <tr>
                        <td align="left"><img src="img/nbplogo.png" width="30"></td>
                        <td align="right">Concerned Copy</td>
                    </tr>

                    <tr>
                        <td align="left"><br>Serial No._______</td>
                        <td align="right"><br>Date:________</td>
                        
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 16px;"><center><br><br><b>National Bank of Pakistan</b><br><br></center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>QUAID-E-AWAM UNIVERSITY OF ENGINEERING SCIENCE & TECHNOLOGY NAWABSHAH</center></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center><br><br>Please receive and credit to QUEST</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Account No: NIDA-11 -7</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Challan Fees</center></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="font-size: 10px;"><center>Sig. & Stamp of Sectional Head (QUEST)</center><br><br></td>
                    </tr>


                    <tr>
                        <td style="font-size: 12px;"><b>Name:</b></td>
                        <td style="font-size: 12px;"><b><b><?= $row['studentName']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Father's Name:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['father']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>Roll No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['seatNo']; ?></b></td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;"><b>NIC No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['nic']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Cell No:</b></td>
                        <td style="font-size: 12px;"><b><?= $row['cellNo']; ?></b></td>
                    </tr>

                    <tr>
                        <td style="font-size: 12px;"><b>Signature of Student:</b></td>
                        <td style="font-size: 12px;"><b>_________________</b><br><br></td>
                    </tr>

                    <tr>
                        <td></td>
                    </tr>
                    <tr><td colspan="2">
                        <div class="feeStructure">
                            <table align="left" border="1" width="100%">
                                <tr>
                                    <td align="left" style="font-size: 12px;">Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Amount</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">1.Examination Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">2.Pass Marks Certificate Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">3.Degree Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">4.Transcript Fees</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">5.Others</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>
    
                                <tr>
                                    <td align="left" style="font-size: 12px;">Total</td>
                                    <td align="left" style="font-size: 12px;">Rs.</td>
                                </tr>                                 
                            </table>
                        </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px;" colspan="2"><br>Rupees in words: _____________________ <br><br> ______________________________________<br><br><br><br><br><br></td>
                    </tr>
                    <tr>
                        <td align="left" style="font-size: 14px;"><r<b>CASHIER</b></td>
                        <td align="right" style="font-size: 14px;"><b>OFFICER</b></td>
                        
                    </tr>
                </table>
            </div>

            <div class="clearCont"></div>
            
                
        </div>
    </div>

                                <?php
                                       }
                                        }
                                ?>

            

    </form>
                            
    </div>

    <script>
                    function PrintPage(){

                        var body = document.getElementById('body').innerHTML;
                        var  mainCenter = document.getElementById('mainCenter').innerHTML;

                        document.getElementById('body').innerHTML = mainCenter;

                        window.print();

                        document.getElementById('body').innerHTML = body;
                    }
                  //  window.addEventListener('DOMContentLoaded',(event) => {
                    //    PrintPage()
                      //  setTimeout(function(){ window.close()}, 750)
                 //   });
                </script>
                    <button onclick="PrintPage()" class="btn btn-primary" id="print-btn">Print</button>

       
           
    </div>
</div>
</div>
</div>



    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>

<?php
if (isset($_POST['uploadBtn']) && $_POST['uploadBtn'] == 'Upload') {
    
    //print_r($_FILES["uploadedFile"]);
    $fileName = $_FILES["uploadfile"]["name"];
    $tempName = $_FILES["uploadfile"]["tmp_name"];
    $temp = explode(".", $_FILES["uploadfile"]["name"]);
    $newfilename = round(microtime(true)) . '.' . end($temp);
    $folderName = "profileUpload/" . $newfilename;

    $sqlProfileImg = "UPDATE students SET profile_url='$folderName' WHERE
            id='$userId'";


    $result = mysqli_query($conn,$sqlProfileImg) or die(mysqli_error());

    if($result){
        echo "Record Success";
    }else
        echo "Sorry" . mysqli_error($conn);
    

    

    move_uploaded_file($tempName, $folderName);
}

if(isset($_POST['sub'])){

$userId1 = $userId;

$stName = $_POST['studentName'];
$father = $_POST['father'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$nic = $_POST['nic'];
$cellNo = $_POST['cellNo'];
$seatNo = $_POST['seatNo'];
$batch = $_POST['batch'];
$enrollNo = $_POST['enrollNo'];
$department = $_POST['department'];
$dateOfAdmission = $_POST['dateOfAdmission'];
$stYear = $_POST['stYear'];
$semester = $_POST['semester'];
$examType = $_POST['examType'];
$examFees = $_POST['examFees'];
$sub1 = $_POST['sub1'];
$sub2 = $_POST['sub2'];
$sub3 = $_POST['sub3'];
$sub4 = $_POST['sub4'];
$sub5 = $_POST['sub5'];
$sub6 = $_POST['sub6'];
$sub7 = $_POST['sub7'];
$sub8 = $_POST['sub8'];
$sub9 = $_POST['sub9'];
$sub10 = $_POST['sub10'];

//$conn = mysqli_connect('localhost','root','','qefs');

//$sql = mysqli_query("INSERT INTO students (studentName,father,surname,nic,cellNo, seatNo, batch, enrollNo,department,dateOfAdmission,semester,examType,examFees) 
  //                                         VALUES('$stName','$father','$surname','$nic','$cellNo', '$seatNo', '$batch','$enrollNo','$department','$dateOfAdmission','$semester','$examType','$examFees')");

$sql = "UPDATE students SET studentName='$stName',father='$father',surname='$surname',email='$email',nic='$nic',cellNo='$cellNo', seatNo='$seatNo', batch='$batch', enrollNo='$enrollNo',department='$department',dateOfAdmission='$dateOfAdmission',stYear='$stYear', semester='$semester',examType='$examType',examFees='$examFees',sub1='$sub1',sub2='$sub2',sub3='$sub3',sub4='$sub4',sub5='$sub5',sub6='$sub6',sub7='$sub7',sub8='$sub8',sub9='$sub9',sub10='$sub10' WHERE
            id='$userId1'";


$result = mysqli_query($conn,$sql);

if($result){
    echo "Record Success";
}else
    echo "Sorry" . mysqli_error($conn);
}



mysqli_close($conn);



?>
