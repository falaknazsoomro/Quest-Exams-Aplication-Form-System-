<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show All Records</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card mt-5">
                    <div class="card-header">
                        <h4>Show All Records</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Student Name</th>
                                            <th>Father's Name</th>
                                            <th>Surname</th>
                                            <th>Cell No</th>
                                            <th>Seat No</th>
                                            <th>Picture</th>

                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php 
                                                include ('connection.php');

                                                $query = "SELECT * FROM students";
                                                $query_run = mysqli_query($conn,$query);

                                                if (mysqli_num_rows($query_run) > 0)
                                                {
                                                    foreach($query_run as $row)
                                                    {
                                                    ?>
                                                        <tr>
                                                            <td><?= $row['id']; ?></td>
                                                            <td><?= $row['studentName']; ?></td>
                                                            <td><?= $row['father']; ?></td>
                                                            <td><?= $row['surname']; ?></td>
                                                            <td><?= $row['cellNo']; ?></td>
                                                            <td><?= $row['seatNo']; ?></td>
                                                            <td><img src="<?= $row['profile_url']; ?>" width="40" ></td>

                                                        </tr>
                                                    <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <tr>
                                                        <td colspan="6">No Record Found</td>
                                                    </tr>
                                                    <?php
                                                }
                                        
                                        ?>
                                    </tbody>
                                </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>