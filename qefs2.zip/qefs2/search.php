<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show All Records</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card mt-5">
                    <div class="card-header">
                        <h4>Show All Records</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">

                        <form action="" method="POST">
                            <input type="text" name="id" placeholder="Enter Student Id" />
                            <input type="submit" name="search" value="Search by Id">

                        </form>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Student Name</th>
                                            <th>Father's Name</th>
                                            <th>Surname</th>
                                            <th>Cell No</th>
                                            <th>Seat No</th>

                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php 
                                                include ('connection.php');

                                                $query = "SELECT * FROM students";
                                                $query_run = mysqli_query($conn,$query);

                                                if(isset($_POST['search']))
                                                {
                                                    $id = $_POST['id'];

                                                    $query = "SELECT * FROM students where id='$id'";
                                                    $query_run = mysqli_query($conn,$query);

                                                    while($row = mysqli_fetch_array($query_run))
                                                    {
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $row['id']; ?></td>
                                                            <td><?= $row['studentName']; ?></td>
                                                            <td><?= $row['father']; ?></td>
                                                            <td><?= $row['surname']; ?></td>
                                                            <td><?= $row['cellNo']; ?></td>
                                                            <td><?= $row['seatNo']; ?></td>

                                                        </tr>

                                                        <?php
                                                    }
                                                }
                                                ?>
                                                                                                          
                                                 
                                    </tbody>
                                </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>