-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2023 at 02:00 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qefs`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `studentName` varchar(255) NOT NULL,
  `father` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password1` varchar(255) NOT NULL,
  `conPassword1` varchar(255) NOT NULL,
  `nic` varchar(255) NOT NULL,
  `cellNo` varchar(255) NOT NULL,
  `seatNo` varchar(255) NOT NULL,
  `batch` varchar(255) NOT NULL,
  `enrollNo` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `dateOfAdmission` date NOT NULL,
  `stYear` varchar(255) NOT NULL,
  `semester` varchar(255) NOT NULL,
  `examType` varchar(255) NOT NULL,
  `examFees` varchar(255) NOT NULL,
  `sub1` varchar(255) NOT NULL,
  `sub2` varchar(255) NOT NULL,
  `sub3` varchar(255) NOT NULL,
  `sub4` varchar(255) NOT NULL,
  `sub5` varchar(255) NOT NULL,
  `sub6` varchar(255) NOT NULL,
  `sub7` varchar(255) NOT NULL,
  `sub8` varchar(255) NOT NULL,
  `sub9` varchar(255) NOT NULL,
  `sub10` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `studentName`, `father`, `surname`, `email`, `password1`, `conPassword1`, `nic`, `cellNo`, `seatNo`, `batch`, `enrollNo`, `department`, `dateOfAdmission`, `stYear`, `semester`, `examType`, `examFees`, `sub1`, `sub2`, `sub3`, `sub4`, `sub5`, `sub6`, `sub7`, `sub8`, `sub9`, `sub10`) VALUES
(14, 'Sajjad', 'Allah Dad', 'Chandio', 'ali@gmail.com', '123', '', '', '11', '11', '11', '111', 'I.T', '2023-01-01', '', '11', 'Regular', '11', '', '', '', '', '', '', '', '', '', ''),
(20, 'Falak Naz', 'Aftab Ahmed', 'Soomro', '', '', '', '45403-756523-1', '09903490349034', '20IT06', '20', '5646', 'I.T', '2023-04-20', '', '34', 'Supplimentary', '2000', '', '', '', '', '', '', '', '', '', ''),
(21, 'Falak Naz', 'Aftab Ahmed', 'Soomro', '', '', '', '45403-756523-1', '09903490349034', '20IT06', '20', '5646', 'I.T', '2023-04-20', '2023', '34', 'Supplimentary', '2000', '', '', '', '', '', '', '', '', '', ''),
(22, 'Falak Naz', 'Aftab Ahmed', 'Soomro', '', '', '', '45403-756523-1', '09903490349034', '20IT06', '20', '5646', 'I.T', '2023-04-20', '2023', '34', 'Supplimentary', '2000', '', '', '', '', '', '', '', '', '', ''),
(23, 'Falak', 'Aftab Ahmed', 'Soomro', '', '', '', '45403-0795292-1', '03313132', '20KIT', '20', '5646', 'I.T', '2023-12-31', '23', 'sdaf', 'Supplimentary', '34344', '', 'Physics', 'Chemistry', 'Biology', 'Pakistan Studies', 'Islamiyat', 'Urdu', 'Sindhi', 'Arabic', 'English'),
(24, 'Falak', 'Aftab Ahmed', 'Soomro', '', '', '', '45403-0795292-1', '03313132', '20KIT', '20', '5646', 'I.T', '2023-12-31', '23', 'sdaf', 'Supplimentary', '34344', '', 'Physics', 'Chemistry', 'Biology', 'Pakistan Studies', 'Islamiyat', 'Urdu', 'Sindhi', 'Arabic', 'English'),
(25, 'bhoongar', 'Aftab Ahmed', 'Soomro', 'aftabksoomro@gmail.com', '', '', '45403-0795292-1', '090-89473238', '20KIT', '43', '345', 'Information Technology', '2023-04-05', '2023', '34', 'Supplimentary', '2000', 'Computer', 'Physics', 'Chemistry', 'Biology', '', '', '', '', '', ''),
(26, 'Falak1', 'Aftab Ahmed', 'Soomro', 'nafesabegam123@gmail.com', '', '', '45403-0795292-1', '03313132', '20KIT', '20', '5646', 'I.T', '2023-12-31', '2023', '34', 'Regular', '34344', '', 'Physics', 'Chemistry', 'Biology', 'Pakistan Studies', 'Islamiyat', 'Urdu', 'Sindhi', 'Arabic', 'English');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `studentName` varchar(255) NOT NULL,
  `father` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password1` varchar(255) NOT NULL,
  `conPassword1` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `studentName`, `father`, `email`, `password1`, `conPassword1`) VALUES
(0, 'Falak', 'Aftab Ahmed', 'falaknazsoomro8@gmail.com', '123456789', '123456789'),
(0, 'Bhoongar', 'Aftab Ahmed', 'bhoongarsoomro1@gmail.com', '123', '123'),
(0, 'Bhoongar', 'Aftab Ahmed', 'bhoongarsoomro1@gmail.com', '123', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
