<?php 

include ('connection.php');

sessionCheck();

$userId = $_SESSION['userID'];

$query = mysqli_query($conn, "SELECT * FROM students WHERE id = '$userId' LIMIT 1");

    $dataRow = mysqli_fetch_array($query);

    $accType = $dataRow['userType'];

    if($accType == 1)
    {
        header("location:challanPanel.php");
        exit();
    }

    $stName1 = $dataRow['studentName'];
    $father1 = $dataRow['father'];
    $surname1 = $dataRow['surname'];
    $email1 =$dataRow['email'];
    $nic1 = $dataRow['nic'];
    $profileUrl = $dataRow['profile_url'];
   
$cellNo1 = $dataRow['cellNo'];
$seatNo1 = $dataRow['seatNo'];
$batch1 = $dataRow['batch'];
$enrollNo1 = $dataRow['enrollNo'];
$department1 = $dataRow['department'];
$dateOfAdmission1 = $dataRow['dateOfAdmission'];
$stYear1 = $dataRow['stYear'];
$semester1 = $dataRow['semester'];
$examType1 = $dataRow['examType'];
$examFees1 = $dataRow['examFees'];
$sub11 = $dataRow['sub1'];
$sub21 = $dataRow['sub2'];
$sub31 = $dataRow['sub3'];
$sub41 = $dataRow['sub4'];
$sub51 = $dataRow['sub5'];
$sub61 = $dataRow['sub6'];
$sub71 = $dataRow['sub7'];
$sub81 = $dataRow['sub8'];
$sub91 = $dataRow['sub9'];
$sub101 = $dataRow['sub10'];

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Online Examination System</title>

    <style>

        table, th, td {
        border: 1px solid black;
        }

        .navbar-brand img{
            width:70px;
            height:70px;
            border-radius:50%;
            border:2px solid white;
        }
    </style>
  </head>
  <body>

  <div class="container-fluid">
    <div class="row">

    <div class="col-md-2">

  <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: black;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="<?php echo($profileUrl);?>" width="50">
    <br><?php echo $stName1; ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">My Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="challanUpdated1.php">Download Challan</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="challanUpload1.php">Upload Challan</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="admitCard1.php">Download Slip</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>
       
      </ul>
      
    </div>
  </div>
</nav>
</div>

<div class="col-md-10">

<div class="container">

        <br>
        <div class="row">

            <div class="col-md-4">
                <img src="img/logo.png" width="130" height="130" alt="Quest Logo">
            </div>

            <div class="col-md-8">
                <h2>
                    <centre>QUAID-E-AWAM UNIVERSITY OF</centre></h2>
                    <h4>ENGINEERING SCIENCE & TECHNOLOGY, NAWABSHAH, SINDH</h4>
            </div>
        </div>



        <br><br>
        <div class="col-2 p-4">
        <img src="<?php echo $profileUrl ?>" alt="" width="100" height="100">
                
                <?php
                if($profileUrl == "")
                {
                    echo('<form method="POST" action="" enctype="multipart/form-data">
                <div class="upload-wrapper">
                <span class="file-name">Choose a file...</span>
                <label for="file-upload">Browse<input type="file" id="file-upload" name="uploadfile"></label>
                </div>
                <input type="submit" name="uploadBtn" value="Upload" />
            </form>');

                }

                else{

                }
                
                ?>
        </div>
            <form action="" method="post">

                <div class="row">
                    <div class="col-md-4">
                        <label for=""><strong>Examination Type:</strong></label>
                        
                          <input type="radio" id="Regular" name="examType" value="Regular">
                          <label for="Regular">Regular</label>
                          <input type="radio" id="supply" name="examType" value="Supplimentary">
                          <label for="supply">Supplementary</label>
                        
                    </div>

                    <div class="col-md-4">
                        <label for=""><strong>Term / Semester:</strong></label>
                        <input type="text" name="semester" value="<?php echo $semester1; ?>">
                    </div>

                    <div class="col-md-4">
                        <label for=""><strong>Year:</strong></label>
                        <input type="text" name="stYear" value="<?php echo $stYear1; ?>">
                        
                    </div>
                </div>


                <br><br>

            <!-- Grid System -->


            <div class="container-fluid">
            
                <div class="row">
                <div class="col-10 p-4">
                
                <div class="row">

                <div class="col-6 p-3">
                    <label for="">Name</label>
                        <input type="text" name="studentName" class="form-control" value="<?php echo $stName1; ?>">    
                    </div>

                    <div class="col-6 p-3">

                        <label for="">ID/Roll No</label>
                        <input type="text" name="seatNo" class="form-control" value="<?php echo $seatNo1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Father's Name</label>
                        <input type="text" name="father" class="form-control" value="<?php echo $father1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Batch</label>
                        <input type="text" name="batch" class="form-control" value="<?php echo $batch1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Surname</label>
                        <input type="text" name="surname" class="form-control" value="<?php echo $surname1; ?>">
                    </div>

                    

                    <div class="col-6 p-3">    
                        <label for="">Email Address</label>
                        <input type="text" name="email" class="form-control" value="<?php echo $email1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">NIC No.</label>
                        <input type="text" name="nic" class="form-control" value="<?php echo $nic1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Enroll No.</label>
                        <input type="text" name="enrollNo" class="form-control" value="<?php echo $enrollNo1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Cell No.</label>
                        <input type="text" name="cellNo" class="form-control" value="<?php echo $cellNo1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Department</label>
                        <input type="text" name="department" class="form-control" value="<?php echo $department1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Date</label>
                        <input type="date" name="dateOfAdmission"class="form-control" value="<?php echo $dateOfAdmission1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Examination Fees Rs.</label>
                        <input type="text" name="examFees" class="form-control" value="<?php echo $examFees1; ?>">
                    </div>

                   

                 


                </div>
                </div>
                
                
                
                


                </div>
                </div>



            <!-- Grid System ends -->



                <br>
            <h6>I wish to appear in the following subjects</h6>

            <br>


            <table width="95%" text-align="center">
                <tr>

                    <th style="text-align:center;">1</th>
                    <td><input type="text" name="sub1" class="form-control" value="<?php echo $sub11; ?>"></td>

                    <th style="text-align:center;">2</th>
                    <td><input type="text" name="sub2" class="form-control" value="<?php echo $sub21; ?>"></td>

                </tr>

                <tr>

                    <th style="text-align:center;">3</th>
                    <td><input type="text" name="sub3" class="form-control" value="<?php echo $sub31; ?>"></td>

                    <th style="text-align:center;">4</th>
                    <td><input type="text" name="sub4" class="form-control" value="<?php echo $sub41; ?>"></td>

                </tr>


                <tr>

                    <th style="text-align:center;">5</th>
                    <td><input type="text" name="sub5" class="form-control" value="<?php echo $sub51; ?>"></td>

                    <th style="text-align:center;">6</th>
                    <td><input type="text" name="sub6" class="form-control" value="<?php echo $sub61; ?>"></td>

                </tr>

                <tr>

                    <th style="text-align:center;">7</th>
                    <td><input type="text" name="sub7" class="form-control" value="<?php echo $sub71; ?>"></td>

                    <th style="text-align:center;">8</th>
                    <td><input type="text" name="sub8" class="form-control" value="<?php echo $sub81; ?>"></td>

                </tr>

                <tr>

                    <th style="text-align:center;">9</th>
                    <td><input type="text" name="sub9" class="form-control" value="<?php echo $sub91; ?>"></td>

                    <th style="text-align:center;">10</th>
                    <td><input type="text" name="sub10" class="form-control" value="<?php echo $sub101; ?>"></td>

                </tr>

            </table>

            <br>
            <input type="submit" name="sub" value="Submit">
           



            </form>
    </div>
</div>
</div>
</div>



    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>

<?php
if (isset($_POST['uploadBtn']) && $_POST['uploadBtn'] == 'Upload') {
    
    //print_r($_FILES["uploadedFile"]);
    $fileName = $_FILES["uploadfile"]["name"];
    $tempName = $_FILES["uploadfile"]["tmp_name"];
    $temp = explode(".", $_FILES["uploadfile"]["name"]);
    $newfilename = round(microtime(true)) . '.' . end($temp);
    $folderName = "profileUpload/" . $newfilename;

    $sqlProfileImg = "UPDATE students SET profile_url='$folderName' WHERE
            id='$userId'";


    $result = mysqli_query($conn,$sqlProfileImg) or die(mysqli_error());

    if($result){
        echo "Record Success";
    }else
        echo "Sorry" . mysqli_error($conn);
    

    

    move_uploaded_file($tempName, $folderName);
}

if(isset($_POST['sub'])){

$userId1 = $userId;

$stName = $_POST['studentName'];
$father = $_POST['father'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$nic = $_POST['nic'];
$cellNo = $_POST['cellNo'];
$seatNo = $_POST['seatNo'];
$batch = $_POST['batch'];
$enrollNo = $_POST['enrollNo'];
$department = $_POST['department'];
$dateOfAdmission = $_POST['dateOfAdmission'];
$stYear = $_POST['stYear'];
$semester = $_POST['semester'];
$examType = $_POST['examType'];
$examFees = $_POST['examFees'];
$sub1 = $_POST['sub1'];
$sub2 = $_POST['sub2'];
$sub3 = $_POST['sub3'];
$sub4 = $_POST['sub4'];
$sub5 = $_POST['sub5'];
$sub6 = $_POST['sub6'];
$sub7 = $_POST['sub7'];
$sub8 = $_POST['sub8'];
$sub9 = $_POST['sub9'];
$sub10 = $_POST['sub10'];

//$conn = mysqli_connect('localhost','root','','qefs');

//$sql = mysqli_query("INSERT INTO students (studentName,father,surname,nic,cellNo, seatNo, batch, enrollNo,department,dateOfAdmission,semester,examType,examFees) 
  //                                         VALUES('$stName','$father','$surname','$nic','$cellNo', '$seatNo', '$batch','$enrollNo','$department','$dateOfAdmission','$semester','$examType','$examFees')");

$sql = "UPDATE students SET studentName='$stName',father='$father',surname='$surname',email='$email',nic='$nic',cellNo='$cellNo', seatNo='$seatNo', batch='$batch', enrollNo='$enrollNo',department='$department',dateOfAdmission='$dateOfAdmission',stYear='$stYear', semester='$semester',examType='$examType',examFees='$examFees',sub1='$sub1',sub2='$sub2',sub3='$sub3',sub4='$sub4',sub5='$sub5',sub6='$sub6',sub7='$sub7',sub8='$sub8',sub9='$sub9',sub10='$sub10' WHERE
            id='$userId1'";


$result = mysqli_query($conn,$sql);

if($result){
    echo "Record Success";
}else
    echo "Sorry" . mysqli_error($conn);
}



mysqli_close($conn);



?>
