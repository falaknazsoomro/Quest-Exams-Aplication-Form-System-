<?php
include ('connection.php');

$challanId = $_POST['pId'];
$setVerified = 1;


//update Query 0 with 1 then if condition that is query successfully run then send feedback to html page.
$challanStatus = "UPDATE challan SET verify='$setVerified' WHERE
            challanId='$challanId'";


    $result = mysqli_query($conn, $challanStatus) or die(mysqli_error());
    
    echo $challanId."0";
?>