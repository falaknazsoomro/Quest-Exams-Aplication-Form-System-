<?php 
if (isset($_POST['uploadBtn']) && $_POST['uploadBtn'] == 'Upload') {
    
    //print_r($_FILES["uploadedFile"]);
    $fileName = $_FILES["uploadedFile"]["name"];
    $tempName = $_FILES["uploadedFile"]["tmp_name"];
    $temp = explode(".", $_FILES["uploadedFile"]["name"]);
    $newfilename = round(microtime(true)) . '.' . end($temp);
    $folderName = "profileUpload/" . $newfilename;

    //echo $folderName;

    move_uploaded_file($tempName, $folderName);



    }
?>