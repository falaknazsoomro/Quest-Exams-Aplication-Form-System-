<?php

include ('connection.php');

sessionCheck();

$userId = $_SESSION['userID'];

$query = mysqli_query($conn, "SELECT * FROM students WHERE id = '$userId' LIMIT 1");

    $dataRow = mysqli_fetch_array($query);

    $accType = $dataRow['userType'];

    if($accType == 1)
    {
        header("location:challanPanel.php");
        exit();
    }

    $stName1 = $dataRow['studentName'];
    $father1 = $dataRow['father'];
    $surname1 = $dataRow['surname'];
    $email1 =$dataRow['email'];
    $nic1 = $dataRow['nic'];
    $profileUrl = $dataRow['profile_url'];


?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

     <!--<script src="js/html2pdfbundle.js"></script>-->
     <script src="https://raw.githack.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js"></script>
    <script src="js/pdf.js"></script>

    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Online Examination System</title>

    
  </head>
  <body id="body">

  <div class="container-fluid">
    <div class="row">

    <div class="col-md-2">

  <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: black;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="<?php echo($profileUrl);?>" width="50">
    <br><?php echo $stName1; ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">My Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="challanUpdated1.php">Download Challan</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="uploadChallan1.php">Upload Challan</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="admitCard1.php">Download Slip</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>
       
      </ul>
      
    </div>
  </div>
</nav>
</div>

<div class="col-md-10">

<div class="container">

<div>
    <form method="POST" action="uploadChallan.php" enctype="multipart/form-data">
                <div>
                    <label>ROLL # <input type="text" name="rollNo" /></lable>
                </div>
                <div>
                    <label>Challan # <input type="text" name="challanNum" /></lable>
                </div>
                <div class="upload-wrapper">
                <span class="file-name">Choose a file...</span>
                <label for="file-upload">Browse<input type="file" id="file-upload" name="uploadfile"></label>
                </div>
                <input type="submit" name="uploadBtn" value="Upload" />
            </form>
    </div>

</div>
</div>
  </body>
</html>

