<?php 
//session_start();
        include ('connection.php');

                            if(isset($_POST['signin'])){

                                $query = "SELECT * FROM students WHERE email='$_POST[email]' AND password1='$_POST[password1]'";
                                
                                $result=mysqli_query($conn,$query);
                                
                                $data = mysqli_fetch_array($result);

                                $accType = $data['userType'];

                                if(mysqli_num_rows($result)==1)
                                {
                                  if($accType == 1)
                                  {
                                    $userId = $data['id'];    
                                    $_SESSION['userID'] = $userId;
                                    header("location:challanPanel.php");
                                    exit();
                                  }
                                  else
                                  {
                                    $userId = $data['id'];    
                                    $_SESSION['userID'] = $userId;
                                    //echo $userId;
                                    //echo "Correct";
                                    //start session function will be called here.
                                    header("location:index.php");
                                    exit();
                                  }
                                  
                                }
                                else
                                {
                                    echo "Incorrect username or password";
                                }
                            }
                      ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login_Exam_form_system</title>
    <link href="css/1bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container-fluid  d-flex justify-content-center backimg align-items-center ">
        <div class=" shadow  new mt-4  rounded  ">
            <div class="row ">
                <div class="col-12 p-4">
                   
                    <form method="post">
                        <div class="mb-5">
                            <h1 class="text-center text-dark"> <span>Login</span></h1>
                        </div>
                        <!-- Email input -->
                        <div class="form-outline mb-4">
                          <input type="email" id="form2Example1" name="email" class="form-control" placeholder="Email " />
                          
                        </div>
                      
                        <!-- Password input -->
                        <div class="form-outline mb-4">
                          <input type="password" id="form2Example2" name="password1" class="form-control " placeholder="Password"/>
                          
                        </div>
                      
                        <!-- 2 column grid layout for inline styling -->
                        <div class="row mb-4">
                          <div class="col d-flex justify-content-center">
                            <!-- Checkbox -->
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" value="" id="form2Example31" checked />
                              <label class="form-check-label" for="form2Example31"> Remember me </label>
                            </div>
                          </div>
                      
                          <div class="col">
                            <!-- Simple link -->
                            <a href="#!">Forgot password?</a>
                          </div>
                        </div>
                      
                        <!-- Submit button -->
                        <div class="col d-flex justify-content-center">
                                
                        <input type="submit" name="signin" class="btn btn-primary btn-block btn-lg gradient-custom-4 w-50 " value="Sign In">
                        </div>
                        
                      
                        <!-- Register buttons -->
                        <div class="text-center">
                          <p>Not a member? <a href="Register.php">Register</a></p>
                          <p>or sign up with:</p>
       
                        </div>
                      </form>

                      
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
        crossorigin="anonymous"></script>
</body>

</html>