<?php 

 include ('connection.php');
$conn = mysqli_connect('localhost','root','','qefs');
if($conn){
     echo "Connected";
}
else{
    echo "Could not connect";
}


if(isset($_POST['sub'])){
$id=0;
$stName = $_POST['studentName'];
$father = $_POST['father'];
$surname = $_POST['surname'];
$cellNo = $_POST['cellNo'];
$seatNo = $_POST['seatNo'];
$batch = $_POST['batch'];
$enrollNo = $_POST['enrollNo'];
$department = $_POST['department'];
$dateOfAdmission = $_POST['dateOfAdmission'];
$stYear = $_POST['stYear'];
$semester = $_POST['semester'];
$examType = '';
$examFees = $_POST['examFees'];

$sql = "INSERT INTO student VALUES($id,$stName','$father','$surname','$cellNo', '$seatNo', '$batch','$enrollNo','$department','$dateOfAdmission','$semester','$examType','$examFees')";

// if ($conn->query($sql) === TRUE) {
//     echo "New record created successfully";
//   } else {
//     echo "Error: " . $sql . "<br>" . $conn->error;
//   }
// }
$result = mysqli_query($conn,$sql);

if($result){
    echo "Record Success";
}else
    echo "Sorry";
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quest Online Examination Form</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">


    <style>

        table, th, td {
        border: 1px solid black;
        }
    </style>
</head>
<body>
    <div class="container">

        <br>
        <div class="row">

            <div class="col-md-4">
                <img src="img/logo.png" width="130" height="130" alt="Quest Logo">
            </div>

            <div class="col-md-8">
                <h2>
                    <centre>QUAID-E-AWAM UNIVERSITY OF </h2>
                    <h3>ENGINEERING SCIENCE & TECHNOLOGY, NAWABSHAH, SINDH</centre></h3>
            </div>
        </div>



        <br><br>
            <form action="" method="post">

                <div class="row">
                    <div class="col-md-4">
                        <label for=""><strong>Examination Type:</strong></label>
                        
                          <input type="radio" id="Regular" name="examType" value="Regular">
                          <label for="Regular">Regular</label>
                          <input type="radio" id="supply" name="examType" value="Supplimentary">
                          <label for="supply">Supplementary</label>
                        
                    </div>

                    <div class="col-md-4">
                        <label for=""><strong>Term / Semester:</strong></label>
                        <input type="text" name="semester" required>
                    </div>

                    <div class="col-md-4">
                        <label for=""><strong>Year:</strong></label>
                        <input type="text" name="stYear">
                    </div>
                </div>


                <br><br>

            <!-- Grid System -->


            <div class="container-fluid">
            
                <div class="row">
                <div class="col-10 p-4">
                
                <div class="row">

                <div class="col-6 p-3">
                    <label for="">Name</label>
                        <input type="text" name="studentName" class="form-control">    
                    </div>

                    <div class="col-6 p-3">

                        <label for="">ID/Seat No</label>
                        <input type="text" name="seatNo" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Father's Name</label>
                        <input type="text" name="father" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Batch</label>
                        <input type="text" name="batch" class="form-control">
                    </div>


                    <div class="col-6 p-3">    
                        <label for="">Surname</label>
                        <input type="text" name="surname" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Enroll No.</label>
                        <input type="text" name="enrollNo" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Cell No.</label>
                        <input type="text" name="cellNo" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Department</label>
                        <input type="text" name="department" class="form-control">
                    </div>


                    <div class="col-6 p-3">    
                        <label for="">Examination Fees Rs.</label>
                        <input type="text" name="examFees" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Date</label>
                        <input type="date" name="dateOfAdmission"class="form-control">
                    </div>


                </div>
                </div>
                <div class="col-2 p-4">
                            <label for="">Picture</label>
                            <img src="img/picture.png" width="200" height="250">    
                </div>


                </div>
                </div>



            <!-- Grid System ends -->



                <br>
            <h6>I wish to appear in the following subjects</h6>

            <br>


            <table width="95%" align ="center">
                <tr>

                    <th style="text-align:center;">1</th>
                    <td><input type="text" class="form-control"></td>

                    <th style="text-align:center;">2</th>
                    <td><input type="text" class="form-control"></td>

                </tr>

                <tr>

                    <th style="text-align:center;">3</th>
                    <td><input type="text" class="form-control"></td>

                    <th style="text-align:center;">4</th>
                    <td><input type="text" class="form-control"></td>

                </tr>


                <tr>

                    <th style="text-align:center;">5</th>
                    <td><input type="text" class="form-control"></td>

                    <th style="text-align:center;">6</th>
                    <td><input type="text" class="form-control"></td>

                </tr>

                <tr>

                    <th style="text-align:center;">7</th>
                    <td><input type="text" class="form-control"></td>

                    <th style="text-align:center;">8</th>
                    <td><input type="text" class="form-control"></td>

                </tr>

                <tr>

                    <th style="text-align:center;">9</th>
                    <td><input type="text" class="form-control"></td>

                    <th style="text-align:center;">10</th>
                    <td><input type="text" class="form-control"></td>

                </tr>

            </table>

            <br>
            <input type="submit" name="sub" value="Save">
           



            </form>
    </div>
</body>
</html>