<?php 

include ('connection.php');

sessionCheck();

$userId = $_SESSION['userID'];

$query = mysqli_query($conn, "SELECT * FROM students WHERE id = '$userId' LIMIT 1");

while($dataRow = mysqli_fetch_array($query)){
    $stName1 = $dataRow['studentName'];
    $father1 = $dataRow['father'];
    $email1 =$dataRow['email'];
    $nic1 = $dataRow['nic'];
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quest Online Examination Form</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">


    <style>

        table, th, td {
        border: 1px solid black;
        }
    </style>
</head>
<body>
    <div class="container">

        <br>
        <div class="row">

            <div class="col-md-4">
                <img src="img/logo.png" width="130" height="130" alt="Quest Logo">
            </div>

            <div class="col-md-8">
                <h2>
                    QUAID-E-AWAM UNIVERSITY OF </h2>
                    <h2>ENGINEERING SCIENCE & TECHNOLOGY, NAWABSHAH, SINDH</h2>
            </div>
        </div>



        <br><br>
            <form action="" method="post">

                <div class="row">
                    <div class="col-md-4">
                        <label for=""><strong>Examination Type:</strong></label>
                        
                          <input type="radio" id="Regular" name="examType" value="Regular">
                          <label for="Regular">Regular</label>
                          <input type="radio" id="supply" name="examType" value="Supplimentary">
                          <label for="supply">Supplementary</label>
                        
                    </div>

                    <div class="col-md-4">
                        <label for=""><strong>Term / Semester:</strong></label>
                        <input type="text" name="semester">
                    </div>

                    <div class="col-md-4">
                        <label for=""><strong>Year:</strong></label>
                        <input type="text" name="stYear">
                    </div>
                </div>


                <br><br>

            <!-- Grid System -->


            <div class="container-fluid">
            
                <div class="row">
                <div class="col-10 p-4">
                
                <div class="row">

                <div class="col-6 p-3">
                    <label for="">Name</label>
                        <input type="text" name="studentName" class="form-control" value="<?php echo $stName1; ?>">    
                    </div>

                    <div class="col-6 p-3">

                        <label for="">ID/Roll No</label>
                        <input type="text" name="seatNo" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Father's Name</label>
                        <input type="text" name="father" class="form-control" value="<?php echo $father1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Batch</label>
                        <input type="text" name="batch" class="form-control">
                    </div>


                    <div class="col-6 p-3">    
                        <label for="">Surname</label>
                        <input type="text" name="surname" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Email Address</label>
                        <input type="text" name="email" class="form-control" value="<?php echo $email1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">NIC No.</label>
                        <input type="text" name="nic" class="form-control" value="<?php echo $nic1; ?>">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Enroll No.</label>
                        <input type="text" name="enrollNo" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Cell No.</label>
                        <input type="text" name="cellNo" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Department</label>
                        <input type="text" name="department" class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Date</label>
                        <input type="date" name="dateOfAdmission"class="form-control">
                    </div>

                    <div class="col-6 p-3">    
                        <label for="">Examination Fees Rs.</label>
                        <input type="text" name="examFees" class="form-control">
                    </div>

                   

                 


                </div>
                </div>
                <div class="col-2 p-4">
                            <label for="">Picture</label>
                            <img src="img/picture.png" width="200" height="250">    
                </div>


                </div>
                </div>



            <!-- Grid System ends -->



                <br>
            <h6>I wish to appear in the following subjects</h6>

            <br>


            <table width="95%" align="center">
                <tr>

                    <th style="text-align:center;">1</th>
                    <td><input type="text" name="sub1" class="form-control"></td>

                    <th style="text-align:center;">2</th>
                    <td><input type="text" name="sub2" class="form-control"></td>

                </tr>

                <tr>

                    <th style="text-align:center;">3</th>
                    <td><input type="text" name="sub3" class="form-control"></td>

                    <th style="text-align:center;">4</th>
                    <td><input type="text" name="sub4" class="form-control"></td>

                </tr>


                <tr>

                    <th style="text-align:center;">5</th>
                    <td><input type="text" name="sub5" class="form-control"></td>

                    <th style="text-align:center;">6</th>
                    <td><input type="text" name="sub6" class="form-control"></td>

                </tr>

                <tr>

                    <th style="text-align:center;">7</th>
                    <td><input type="text" name="sub7" class="form-control"></td>

                    <th style="text-align:center;">8</th>
                    <td><input type="text" name="sub8" class="form-control"></td>

                </tr>

                <tr>

                    <th style="text-align:center;">9</th>
                    <td><input type="text" name="sub9" class="form-control"></td>

                    <th style="text-align:center;">10</th>
                    <td><input type="text" name="sub10" class="form-control"></td>

                </tr>

            </table>

            <br>
            <input type="submit" name="sub" value="Save">
           



            </form>
    </div>
</body>
</html>

<?php

if(isset($_POST['sub'])){

$userId1 = $userId;

$stName = $_POST['studentName'];
$father = $_POST['father'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$nic = $_POST['nic'];
$cellNo = $_POST['cellNo'];
$seatNo = $_POST['seatNo'];
$batch = $_POST['batch'];
$enrollNo = $_POST['enrollNo'];
$department = $_POST['department'];
$dateOfAdmission = $_POST['dateOfAdmission'];
$stYear = $_POST['stYear'];
$semester = $_POST['semester'];
$examType = $_POST['examType'];
$examFees = $_POST['examFees'];
$sub1 = $_POST['sub1'];
$sub2 = $_POST['sub2'];
$sub3 = $_POST['sub3'];
$sub4 = $_POST['sub4'];
$sub5 = $_POST['sub5'];
$sub6 = $_POST['sub6'];
$sub7 = $_POST['sub7'];
$sub8 = $_POST['sub8'];
$sub9 = $_POST['sub9'];
$sub10 = $_POST['sub10'];

//$conn = mysqli_connect('localhost','root','','qefs');

//$sql = mysqli_query("INSERT INTO students (studentName,father,surname,nic,cellNo, seatNo, batch, enrollNo,department,dateOfAdmission,semester,examType,examFees) 
  //                                         VALUES('$stName','$father','$surname','$nic','$cellNo', '$seatNo', '$batch','$enrollNo','$department','$dateOfAdmission','$semester','$examType','$examFees')");

$sql = "UPDATE students SET studentName='$stName',father='$father',surname='$surname',email='$email',nic='$nic',cellNo='$cellNo', seatNo='$seatNo', batch='$batch', enrollNo='$enrollNo',department='$department',dateOfAdmission='$dateOfAdmission',stYear='$stYear', semester='$semester',examType='$examType',examFees='$examFees',sub1='$sub1',sub2='$sub2',sub3='$sub3',sub4='$sub4',sub5='$sub5',sub6='$sub6',sub7='$sub7',sub8='$sub8',sub9='$sub9',sub10='$sub10' WHERE
            id='$userId1'";

            //$sql = "UPDATE students SET sub10='$sub10' WHERE id='$userId1'";

$result = mysqli_query($conn,$sql) or die(mysqli_error());

if($result){
    echo "Record Success";
}else
    echo "Sorry" . mysqli_error($conn);
}

mysqli_close($conn);

?>