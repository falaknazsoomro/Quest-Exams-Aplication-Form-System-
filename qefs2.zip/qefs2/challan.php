<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show All Records</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card mt-5">
                    <div class="card-header">
                        <h4>Show All Records</h4>
                    </div>
                    <div class="card-body">
                        
                        <form action="user_data_print.php" method="POST">
                            <input type="text" name="id" placeholder="Enter Student Id" />
                            <input type="submit" name="search" value="Search by Id">

                        </form>


                        
                       
                                        <?php 
                                                include ('connection.php');

                                                $query = "SELECT * FROM students";
                                                $query_run = mysqli_query($conn,$query);

                                                if(isset($_POST['search']))
                                                {
                                                    $id = $_POST['id'];

                                                    $query = "SELECT * FROM students where id='$id'";
                                                    $query_run = mysqli_query($conn,$query);

                                                    while($row = mysqli_fetch_array($query_run))
                                                    {
                                                        ?>

                                                        <div class="row">

                                                        <div class="col-md-4">
                                                            <p>Bank Copy</p>
                                                            <img src="img/logo.png" width="50">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            <img src="img/nbp.jpg" width="60">
                                                            <br>
                                                            Name: &nbsp;&nbsp;<b><?= $row['studentName']; ?></b><br>
                                                            Father's Name:&nbsp;&nbsp;<b><?= $row['father']; ?></b><br>
                                                            Surname: &nbsp;&nbsp;<b><?= $row['surname']; ?></b><br>
                                                            NIC No: &nbsp;&nbsp;<b><?= $row['nic']; ?></b><br>
                                                            Cell No: &nbsp;&nbsp;<b><?= $row['cellNo']; ?></b><br>
                                                            Seat No: &nbsp;&nbsp;<b><?= $row['seatNo']; ?></b><br>
                                                        </div>

                                                        <div class="col-md-4">
                                                        <p>Office Copy</p>
                                                            <img src="img/logo.png" width="50">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            <img src="img/nbp.jpg" width="60">
                                                            <br>
                                                            Name: &nbsp;&nbsp;<b><?= $row['studentName']; ?></b><br>
                                                            Father's Name:&nbsp;&nbsp;<b><?= $row['father']; ?></b><br>
                                                            Surname: &nbsp;&nbsp;<b><?= $row['surname']; ?></b><br>
                                                            NIC No: &nbsp;&nbsp;<b><?= $row['nic']; ?></b><br>
                                                            Cell No: &nbsp;&nbsp;<b><?= $row['cellNo']; ?></b><br>
                                                            Seat No: &nbsp;&nbsp;<b><?= $row['seatNo']; ?></b><br>
           
                                                        </div>

                                                        <div class="col-md-4">
                                                        <p>Candidate Copy</p>
                                                            <img src="img/logo.png" width="50">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            <img src="img/nbp.jpg" width="60">
                                                            <br>
                                                            Name: &nbsp;&nbsp;<b><?= $row['studentName']; ?></b><br>
                                                            Father's Name:&nbsp;&nbsp;<b><?= $row['father']; ?></b><br>
                                                            Surname: &nbsp;&nbsp;<b><?= $row['surname']; ?></b><br>
                                                            NIC No: &nbsp;&nbsp;<b><?= $row['nic']; ?></b><br>
                                                            Cell No: &nbsp;&nbsp;<b><?= $row['cellNo']; ?></b><br>
                                                            Seat No: &nbsp;&nbsp;<b><?= $row['seatNo']; ?></b><br>

                                                        </div>

                                                        </div>

                                                        

                                                        <?php
                                                    }
                                                }
                                                ?>
                                                                                                          
                                             
                                   
                        </div>
                                
                </div>
                <br>
                <div class="text-center">
                                <a href="user_data_print.php" class="btn btn-primary">Print</a>   
                                </div>
            </div>
        </div>
    </div>
</body>
</html>